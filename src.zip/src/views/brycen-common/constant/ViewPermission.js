export default {
    ONLY_ME: 0,
    ALL: 1,
    MY_DATA_MY_MEMBER: 2,
    ALL_NOT_MONEY: 3
}
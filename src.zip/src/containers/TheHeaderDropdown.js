import React from 'react'
import {
  CImg
} from '@coreui/react'


const TheHeaderDropdown = () => {
  return (


    <div >
          <CImg
            src={'/image/brycen-logo.png'}
            className="brc-lg"
            alt="brycenmyanmar.com"
          />
    </div>
   
  )
}

export default TheHeaderDropdown
